package com.nttdata.mvn;

import org.apache.commons.lang3.ArrayUtils;
/**
 * @package nttdatatallermaven-SBA
 * @author NTTDATA Bootcamp Sebastian Berdonces Agudo
 * @version 1.0
 */
public class App 
{
    public static void main( String[] args )
    {
    	/**
    	 * Metodo para saber si esta vacio el array
    	 */
    	String[] nombres = new String[0];
		System.out.println(ArrayUtils.isEmpty(nombres));
    }
}
